Name: Shubham Hazra
Roll No: 210100143

References:

https://www.physicsread.com/latex-greater-than-symbol/
https://tex.stackexchange.com/questions/29816/algorithm-over-2-pages
https://tex.stackexchange.com/questions/18949/algorithm2e-split-over-several-pages
https://en.wikibooks.org/wiki/LaTeX/Algorithms
https://tex.stackexchange.com/questions/56871/how-to-format-for-loop-for-printing-a-pseudo-code-listing
https://www.overleaf.com/learn/latex/Bibliography_management_in_LaTeX#The_bibliography_file
https://www.overleaf.com/learn/latex/Tables
https://stackoverflow.com/questions/69242920/print-bibliography-empty-bibliography
https://www.reddit.com/r/LaTeX/comments/1tw2af/trouble_with_biblatex_empty_bibliography_error/
https://alipourmousavi.com/blog/index.php/2018/02/08/using-minted-package-in-latex-to-format-codes/

