heap module
===========

.. automodule:: heap
    :members:
    :undoc-members:
    :show-inheritance:
