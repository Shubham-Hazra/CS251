#ifndef _HASHING
#define _HASHING

#include <iostream>
#include <string>
#include <math.h>

using namespace std;


int hash_string(string s, int m);

#endif
