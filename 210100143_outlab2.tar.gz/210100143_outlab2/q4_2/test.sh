g++ -c hashing.cpp -o hash.o
g++ hash.o main.cpp
echo $1 | ./a.out